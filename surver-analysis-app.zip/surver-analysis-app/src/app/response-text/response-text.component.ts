import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-response-text',
  templateUrl: './response-text.component.html',
  styleUrls: ['./response-text.component.css']
})
export class ResponseTextComponent implements OnInit {
  displayedColumns = ['speaker','text', 'score'];
  dataSource = ELEMENT_DATA;
  constructor() { }

  ngOnInit() {
  }

}
export interface PeriodicElement {
  speaker: string;
  text: string;
  score: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  {speaker: '1', text: 'Alexa open ABC Asset Management', score: '0.89961594'},
  {speaker: '2',
  text: 'welcome to ABC Asset Management I can help you with your sales update product details meeting details and budget information what would you like to do I look like', score: '0.9570671'},
  { speaker: '1', text: 'okay you have a free slot next week Wednesday at 2 p.m. do you want to go ahead with this lot yes', score: '0.89961594'},
  { speaker: '2', text: 'welcome to ABC Asset Management I can help you with your sales update product details meeting details and budget information what would you like to do I look like', score: '0.9570671'},
  { speaker: '1', text: 'Alexa open ABC Asset Management', score: '0.89961594'},
  {speaker: '2', text: 'welcome to ABC Asset Management I can help you with your sales update product details meeting details and budget information what would you like to do I look like', score: '0.9570671'},
  { speaker: '1', text: 'Alexa open ABC Asset Management', score: '0.89961594'},
  {speaker: '2', text: 'welcome to ABC Asset Management I can help you with your sales update product details meeting details and budget information what would you like to do I look like', score: '0.9570671'},
];
