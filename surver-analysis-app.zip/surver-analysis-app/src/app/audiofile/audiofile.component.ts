import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-audiofile',
  templateUrl: './audiofile.component.html',
  styleUrls: ['./audiofile.component.css']
})
export class AudiofileComponent implements OnInit {

  selected = 'google';
  selectedAPItest: string ;
  srcResult: any;
  constructor() { }

  ngOnInit() {
  }
  onAPIcall(apiSelected: string) {
    this.selectedAPItest = apiSelected;
    console.log(apiSelected);
  }

  onFileSelected() {
    const inputNode: any = document.querySelector('#file');
    if (typeof (FileReader) !== 'undefined') {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.srcResult = e.target.result;
      };
      reader.readAsArrayBuffer(inputNode.files[0]);
    }
  }
}
